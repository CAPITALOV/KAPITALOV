<?php


namespace cs\services;

use cs\models\Response;
use DateTime;
use yii\helpers\VarDumper;

class DataSets
{
    public static $booleanList = [
        1 => 'Да',
        0 => 'Нет',
    ];
}