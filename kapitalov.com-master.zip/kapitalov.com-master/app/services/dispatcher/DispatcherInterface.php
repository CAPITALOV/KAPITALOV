<?php


namespace cs\services\dispatcher;


interface DispatcherInterface
{


    public static function cron();


} 