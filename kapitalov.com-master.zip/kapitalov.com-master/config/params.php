<?php

return [
    'adminEmail' => 'admin@capitalov.com',
    'mailer'     => [
        'from' => ['capitalov@capitalov.com' => 'Capitalov.com']
    ],
    'chat' => [
        'consultant_id' => (YII_ENV_DEV)? 7 : 6,
    ],
];
