<?php


return [
    'username' => 'capitalov_bot',
    'appName'  => 'capitalov',
    'key'      => '114576187:AAEviNK7YoWjuH5zVgW50Kc8Jg4FrXiLtnA',
    'app'      => [
        'id'          => '20063',
        'hash'        => '51c39b2a0f4d943dab4603c5ac01e07e',
        'title'       => 'Capitalov.com',
        'name'        => 'capitalov',
        'servers'     => [
            'test' => '149.154.167.40:443',
            'prod' => '149.154.167.50:443',

        ],
        'public_keys' => '-----BEGIN RSA PUBLIC KEY-----
MIIBCgKCAQEAwVACPi9w23mF3tBkdZz+zwrzKOaaQdr01vAbU4E1pvkfj4sqDsm6
lyDONS789sVoD/xCS9Y0hkkC3gtL1tSfTlgCMOOul9lcixlEKzwKENj1Yz/s7daS
an9tqw3bfUV/nqgbhGX81v/+7RFAEd+RwFnK7a+XYl9sluzHRyVVaTTveB2GazTw
Efzk2DWgkBluml8OREmvfraX3bkHZJTKX4EQSjBbbdJ2ZXIsRrYOXfaA+xayEGB+
8hdlLmAjbCVfaigxX0CDqWeR1yFL9kwd9P0NsZRPsmoqVwMbMu7mStFai6aIhc3n
Slv8kg9qv1m6XHVQY3PnEw+QQtqSIXklHwIDAQAB
-----END RSA PUBLIC KEY-----'
    ]
];